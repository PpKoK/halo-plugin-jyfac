import { definePlugin } from '@halo-dev/console-shared'

export default definePlugin({
  components: {},
  routes: [],
  extensionPoints: {},
})
