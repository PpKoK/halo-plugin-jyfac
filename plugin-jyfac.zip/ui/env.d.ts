/// <reference types="@rsbuild/core/types" />
/// <reference types="unplugin-icons/types/vue" />
